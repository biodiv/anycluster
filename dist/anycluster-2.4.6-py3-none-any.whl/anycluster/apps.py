from django.apps import AppConfig


class AnyclusterConfig(AppConfig):
    name = 'anycluster'
